# 🚀 Guide d'Installation PlannerIA

## 📋 Prérequis Système

### Logiciels Requis
- **Python 3.11** ou supérieur
- **Git** (optionnel, pour les mises à jour)
- **Ollama** (pour la génération de plans IA)

### Système d'Exploitation
- ✅ Windows 10/11
- ✅ macOS 10.15+
- ✅ Linux Ubuntu 18.04+

---

## ⚡ Installation Rapide (Windows)

### 1. Extraction du Package
```bash
# Extraire PlannerIA_Deployment_XXXXXXXX_XXXXXX.zip
# dans le dossier de votre choix (ex: C:\PlannerIA)
```

### 2. Installation Automatique
```bash
# Double-cliquer sur quick_start.bat
# OU exécuter dans un terminal :
quick_start.bat
```

### 3. Démarrage
```bash
# Le dashboard s'ouvre automatiquement sur :
http://localhost:8521
```

---

## 🔧 Installation Manuelle Détaillée

### Étape 1: Installation Python
1. Télécharger Python 3.11+ depuis https://python.org
2. ⚠️ IMPORTANT: Cocher "Add Python to PATH" lors de l'installation
3. Vérifier l'installation:
```bash
python --version
pip --version
```

### Étape 2: Installation Ollama (pour IA complète)
1. Télécharger Ollama depuis https://ollama.ai
2. Installer et redémarrer l'ordinateur
3. Ouvrir un terminal et exécuter:
```bash
ollama pull llama3.2:latest
ollama serve
```
4. ⚠️ Laisser le terminal Ollama ouvert

### Étape 3: Installation PlannerIA
```bash
# Naviguer vers le dossier extrait
cd C:\cheminers\PlannerIA

# Installer les dépendances
pip install -r requirements.txt

# Lancer le dashboard
python -m streamlit run src/project_planner/dashboard/mvp_v1.py --server.port=8521
```

---

## 🎯 Modes de Fonctionnement

### Mode Dashboard (Recommandé)
✅ **Fonctionne TOUJOURS sans prérequis**
```bash
python -m streamlit run src/project_planner/dashboard/mvp_v1.py --server.port=8521
```
**Accès**: http://localhost:8521

**Fonctionnalités disponibles**:
- 11 modules IA opérationnels
- Visualisations interactives
- Rapports PDF/CSV
- Système vocal
- Analytics temps réel

### Mode Génération IA (Nécessite Ollama)
⚠️ **Requiert Ollama actif**
```bash
# Terminal 1: Ollama
ollama serve

# Terminal 2: PlannerIA CLI
python crew.py "Votre brief de projet"
```

### Mode API (Nécessite Ollama)
⚠️ **Requiert Ollama actif**
```bash
# Terminal 1: Ollama  
ollama serve

# Terminal 2: API
python -m uvicorn src.project_planner.api.main:app --reload
```
**Accès**: http://localhost:8000

---

## 🧪 Tests de Fonctionnement

### Test Rapide Dashboard
```bash
# Lancer le dashboard
python -m streamlit run src/project_planner/dashboard/mvp_v1.py --server.port=8521

# Vérifier dans les logs:
# "11/11 modules opérationnels" = ✅ Succès
```

### Test Modèles ML
```bash
python -c "
from src.project_planner.ml.estimator_model import EstimatorModel
em = EstimatorModel()
print('✅ Modèles ML fonctionnels')
"
```

### Test Complet
```bash
python test_ml_complete.py
```

---

## 🔧 Dépannage

### Erreur "Module not found"
```bash
# Solution:
pip install -r requirements.txt
```

### Erreur Ollama "Connection refused"
```bash
# Solution:
ollama serve
# Puis relancer PlannerIA
```

### Erreur Streamlit
```bash
# Solution:
pip install streamlit --upgrade
```

### Port 8521 occupé
```bash
# Solution: utiliser un autre port
python -m streamlit run src/project_planner/dashboard/mvp_v1.py --server.port=8522
```

---

## 📁 Structure Post-Installation

```
PlannerIA/
├── quick_start.bat           # Script démarrage rapide
├── requirements.txt          # Dépendances Python
├── crew.py                   # CLI génération plans
├── src/                      # Code source
│   └── project_planner/      # Modules principaux
├── data/                     # Données et modèles
│   ├── models/              # Modèles ML pré-entraînés
│   ├── runs/                # Plans générés (créé auto)
│   └── reports/             # Rapports exportés (créé auto)
├── config/                   # Configurations
└── logs/                     # Logs système (créé auto)
```

---

## 🚀 Commandes Essentielles

### Démarrage Dashboard
```bash
python -m streamlit run src/project_planner/dashboard/mvp_v1.py --server.port=8521
```

### Génération Plan (avec Ollama)
```bash
python crew.py "Développer une application mobile de gestion de tâches"
```

### Tests Performance
```bash
python benchmark_complete.py
```

### Mise à Jour
```bash
git pull origin main  # Si installé via Git
pip install -r requirements.txt --upgrade
```

---

## 📞 Support

- 🐛 **Issues**: https://github.com/Michel836/PlannerIA/issues
- 📚 **Documentation**: Voir README.md
- 💡 **Suggestions**: Pull requests bienvenues

---

## ✅ Checklist Installation Réussie

- [ ] Python 3.11+ installé et dans le PATH
- [ ] Dépendances pip installées sans erreur
- [ ] Dashboard accessible sur http://localhost:8521  
- [ ] Message "11/11 modules opérationnels" visible
- [ ] Exports PDF/CSV fonctionnels
- [ ] (Optionnel) Ollama installé et opérationnel
- [ ] (Optionnel) API accessible sur http://localhost:8000

**Installation réussie = Dashboard fonctionnel !**

---

*Version: 1.0.0-deployment | Date: $(date '+%Y-%m-%d')*
