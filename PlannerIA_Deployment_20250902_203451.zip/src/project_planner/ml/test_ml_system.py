"""
Tests d'intégration pour le système ML de PlannerIA
Valide le fonctionnement complet du pipeline d'estimation
"""

import sys
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List

# Configuration logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, str(project_root))

try:
    from src.project_planner.ml.estimator_model import EstimatorModel
    from src.project_planner.ml.synthetic_generator import EnhancedSyntheticGenerator
    from src.project_planner.ml.train_estimator import TrainingDataManager, ModelTrainingPipeline
except ImportError as e:
    logger.error(f"Erreur d'import: {e}")
    sys.exit(1)


class MLSystemTester:
    """Testeur du système ML complet"""
    
    def __init__(self):
        self.test_results = {}
        self.test_data_dir = Path("test_data")
        self.test_data_dir.mkdir(exist_ok=True)
        
    def run_all_tests(self) -> Dict[str, Any]:
        """Exécute tous les tests du système"""
        logger.info("=== DÉBUT DES TESTS SYSTÈME ML ===")
        
        self.test_results = {
            'start_time': datetime.now().isoformat(),
            'tests': {}
        }
        
        # Test 1: Génération de données synthétiques
        self._test_synthetic_generation()
        
        # Test 2: Extraction des caractéristiques
        self._test_feature_extraction()
        
        # Test 3: Entraînement du modèle
        self._test_model_training()
        
        # Test 4: Prédictions
        self._test_predictions()
        
        # Test 5: Sauvegarde/Chargement
        self._test_model_persistence()
        
        # Test 6: Pipeline complet
        self._test_full_pipeline()
        
        # Test 7: Gestion des erreurs
        self._test_error_handling()
        
        self.test_results['end_time'] = datetime.now().isoformat()
        self._print_test_summary()
        
        return self.test_results
    
    def _test_synthetic_generation(self):
        """Test de la génération de données synthétiques"""
        logger.info("Test 1: Génération de données synthétiques")
        
        try:
            generator = EnhancedSyntheticGenerator()
            tasks = generator.generate_realistic_tasks(100)
            
            # Validations
            assert len(tasks) == 100, f"Attendu 100 tâches, reçu {len(tasks)}"
            
            # Vérification structure des tâches
            required_fields = ['id', 'name', 'description', 'duration', 'cost', 'complexity_level']
            for task in tasks[:5]:  # Test sur un échantillon
                for field in required_fields:
                    assert field in task, f"Champ manquant: {field}"
                
                assert task['duration'] > 0, "Durée invalide"
                assert task['cost'] > 0, "Coût invalide"
            
            # Vérification distribution
            complexities = [task['complexity_level'] for task in tasks]
            unique_complexities = set(complexities)
            assert len(unique_complexities) > 1, "Distribution de complexité trop uniforme"
            
            self.test_results['tests']['synthetic_generation'] = {
                'status': 'PASS',
                'tasks_generated': len(tasks),
                'unique_complexities': len(unique_complexities)
            }
            
            # Sauvegarde pour tests suivants
            self.test_tasks = tasks[:50]  # Gardons 50 tâches pour les tests
            
        except Exception as e:
            self.test_results['tests']['synthetic_generation'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur génération synthétique: {e}")
    
    def _test_feature_extraction(self):
        """Test d'extraction des caractéristiques"""
        logger.info("Test 2: Extraction des caractéristiques")
        
        try:
            if not hasattr(self, 'test_tasks'):
                self.test_tasks = self._create_minimal_test_tasks()
            
            model = EstimatorModel()
            features_df = model.extract_features(self.test_tasks)
            
            # Validations
            assert len(features_df) == len(self.test_tasks), "Nombre de lignes incorrect"
            assert len(features_df.columns) > 5, "Pas assez de caractéristiques extraites"
            
            # Vérification présence de colonnes clés
            expected_cols = ['name_length', 'description_length', 'complexity_numeric']
            for col in expected_cols:
                assert col in features_df.columns, f"Colonne manquante: {col}"
            
            # Vérification valeurs
            assert features_df['name_length'].min() >= 0, "Longueurs négatives détectées"
            assert features_df['complexity_numeric'].max() <= 5, "Valeurs de complexité aberrantes"
            
            self.test_results['tests']['feature_extraction'] = {
                'status': 'PASS',
                'features_extracted': len(features_df.columns),
                'samples_processed': len(features_df)
            }
            
        except Exception as e:
            self.test_results['tests']['feature_extraction'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur extraction caractéristiques: {e}")
    
    def _test_model_training(self):
        """Test d'entraînement du modèle"""
        logger.info("Test 3: Entraînement du modèle")
        
        try:
            if not hasattr(self, 'test_tasks'):
                self.test_tasks = self._create_minimal_test_tasks()
            
            model = EstimatorModel()
            training_results = model.train(self.test_tasks)
            
            # Validations
            assert training_results['status'] == 'success', f"Entraînement échoué: {training_results.get('message', '')}"
            assert 'performance_metrics' in training_results, "Métriques manquantes"
            assert 'duration' in training_results['performance_metrics'], "Métriques durée manquantes"
            assert 'cost' in training_results['performance_metrics'], "Métriques coût manquantes"
            
            # Validation cohérence
            duration_r2 = training_results['performance_metrics']['duration']['r2']
            cost_r2 = training_results['performance_metrics']['cost']['r2']
            
            # R² doit être entre -inf et 1, mais on s'attend à des valeurs raisonnables
            assert -2 <= duration_r2 <= 1, f"R² durée aberrant: {duration_r2}"
            assert -2 <= cost_r2 <= 1, f"R² coût aberrant: {cost_r2}"
            
            self.test_results['tests']['model_training'] = {
                'status': 'PASS',
                'duration_r2': duration_r2,
                'cost_r2': cost_r2,
                'samples_used': training_results.get('samples_used', 0)
            }
            
            self.trained_model = model  # Garder pour tests suivants
            
        except Exception as e:
            self.test_results['tests']['model_training'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur entraînement: {e}")
    
    def _test_predictions(self):
        """Test des prédictions"""
        logger.info("Test 4: Prédictions")
        
        try:
            if not hasattr(self, 'trained_model'):
                # Fallback: créer un modèle minimal
                self.trained_model = EstimatorModel()
            
            if not hasattr(self, 'test_tasks'):
                self.test_tasks = self._create_minimal_test_tasks()
            
            # Test prédiction simple
            single_prediction = self.trained_model.predict_task_estimates(self.test_tasks[0])
            
            # Validations prédiction simple
            required_fields = ['task_id', 'duration', 'cost', 'confidence_duration', 'confidence_cost']
            for field in required_fields:
                assert field in single_prediction, f"Champ manquant dans prédiction: {field}"
            
            assert single_prediction['duration'] > 0, "Durée prédite invalide"
            assert single_prediction['cost'] > 0, "Coût prédit invalide"
            assert 0 <= single_prediction['confidence_duration'] <= 1, "Confiance durée invalide"
            
            # Test prédictions multiples
            multiple_predictions = self.trained_model.predict_multiple_tasks(self.test_tasks[:10])
            
            assert len(multiple_predictions) == 10, "Nombre de prédictions incorrect"
            
            # Vérification cohérence des prédictions
            durations = [pred['duration'] for pred in multiple_predictions]
            costs = [pred['cost'] for pred in multiple_predictions]
            
            assert all(d > 0 for d in durations), "Durées négatives détectées"
            assert all(c > 0 for c in costs), "Coûts négatifs détectés"
            assert max(durations) / min(durations) < 100, "Variance durée trop élevée"
            
            self.test_results['tests']['predictions'] = {
                'status': 'PASS',
                'single_prediction': single_prediction,
                'multiple_predictions_count': len(multiple_predictions),
                'duration_range': [min(durations), max(durations)],
                'cost_range': [min(costs), max(costs)]
            }
            
        except Exception as e:
            self.test_results['tests']['predictions'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur prédictions: {e}")
    
    def _test_model_persistence(self):
        """Test sauvegarde/chargement du modèle"""
        logger.info("Test 5: Persistance du modèle")
        
        try:
            if not hasattr(self, 'trained_model'):
                self.trained_model = EstimatorModel()
                self.trained_model.train(self._create_minimal_test_tasks())
            
            # Test sauvegarde
            model_path = self.trained_model.save_model()
            assert Path(model_path).exists(), "Fichier modèle non créé"
            
            # Test chargement
            new_model = EstimatorModel()
            load_success = new_model.load_model(model_path)
            assert load_success, "Échec chargement modèle"
            
            # Test fonctionnement après chargement
            if hasattr(self, 'test_tasks'):
                predictions_original = self.trained_model.predict_multiple_tasks(self.test_tasks[:5])
                predictions_loaded = new_model.predict_multiple_tasks(self.test_tasks[:5])
                
                # Les prédictions devraient être identiques
                for orig, loaded in zip(predictions_original, predictions_loaded):
                    duration_diff = abs(orig['duration'] - loaded['duration'])
                    assert duration_diff < 0.1, f"Différence durée trop élevée: {duration_diff}"
            
            self.test_results['tests']['model_persistence'] = {
                'status': 'PASS',
                'model_path': str(model_path),
                'load_success': load_success
            }
            
        except Exception as e:
            self.test_results['tests']['model_persistence'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur persistance: {e}")
    
    def _test_full_pipeline(self):
        """Test du pipeline complet d'entraînement"""
        logger.info("Test 6: Pipeline complet")
        
        try:
            # Configuration de test
            config = {
                'synthetic_samples': 100,
                'min_samples_required': 50,
                'save_predictions_sample': False  # Pas besoin pour test
            }
            
            pipeline = ModelTrainingPipeline(config)
            results = pipeline.run_full_pipeline()
            
            # Validations
            assert results['status'] in ['completed', 'error'], f"Statut pipeline invalide: {results['status']}"
            
            if results['status'] == 'completed':
                assert 'steps_completed' in results, "Étapes non trackées"
                assert len(results['steps_completed']) >= 3, "Pipeline incomplet"
                assert 'model_training' in results, "Résultats d'entraînement manquants"
            
            self.test_results['tests']['full_pipeline'] = {
                'status': 'PASS' if results['status'] == 'completed' else 'PARTIAL',
                'pipeline_status': results['status'],
                'steps_completed': len(results.get('steps_completed', []))
            }
            
        except Exception as e:
            self.test_results['tests']['full_pipeline'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur pipeline: {e}")
    
    def _test_error_handling(self):
        """Test de la gestion d'erreurs"""
        logger.info("Test 7: Gestion d'erreurs")
        
        try:
            model = EstimatorModel()
            error_tests = {}
            
            # Test 1: Données invalides pour l'entraînement
            try:
                invalid_tasks = [{'invalid': 'data'}]
                result = model.train(invalid_tasks)
                error_tests['invalid_training_data'] = 'handled' if 'error' in result else 'not_handled'
            except Exception:
                error_tests['invalid_training_data'] = 'handled'
            
            # Test 2: Prédiction sans modèle entraîné
            try:
                fresh_model = EstimatorModel()
                prediction = fresh_model.predict_task_estimates({'name': 'test'})
                error_tests['prediction_without_training'] = 'handled' if prediction.get('method') == 'heuristic' else 'not_handled'
            except Exception:
                error_tests['prediction_without_training'] = 'handled'
            
            # Test 3: Chargement de fichier inexistant
            try:
                load_result = model.load_model("nonexistent_model.pkl")
                error_tests['load_nonexistent'] = 'handled' if not load_result else 'not_handled'
            except Exception:
                error_tests['load_nonexistent'] = 'handled'
            
            # Test 4: Données manquantes dans les tâches
            try:
                incomplete_task = {'name': 'Test task'}  # Pas de description, durée, etc.
                prediction = model.predict_task_estimates(incomplete_task)
                error_tests['incomplete_task_data'] = 'handled' if prediction else 'not_handled'
            except Exception:
                error_tests['incomplete_task_data'] = 'handled'
            
            self.test_results['tests']['error_handling'] = {
                'status': 'PASS',
                'error_tests': error_tests,
                'handled_count': sum(1 for v in error_tests.values() if v == 'handled')
            }
            
        except Exception as e:
            self.test_results['tests']['error_handling'] = {
                'status': 'FAIL',
                'error': str(e)
            }
            logger.error(f"Erreur test gestion d'erreurs: {e}")
    
    def _create_minimal_test_tasks(self) -> List[Dict[str, Any]]:
        """Crée un jeu de données minimal pour les tests"""
        return [
            {
                'id': f'test_task_{i}',
                'name': f'Test Task {i}',
                'description': f'Description for test task {i} with various complexity levels',
                'duration': 2.0 + i * 0.5,
                'cost': 1600.0 + i * 400,
                'priority': ['low', 'medium', 'high'][i % 3],
                'task_type': ['frontend', 'backend', 'testing'][i % 3],
                'complexity_level': ['simple', 'medium', 'complex'][i % 3],
                'team_size': (i % 3) + 1,
                'assigned_resources': [f'resource_{j}' for j in range((i % 3) + 1)],
                'dependencies': [f'dep_{j}' for j in range(i % 2)],
                'deliverables': [f'deliverable_{j}' for j in range((i % 3) + 1)]
            }
            for i in range(20)
        ]
    
    def _print_test_summary(self):
        """Affiche un résumé des tests"""
        print("\n" + "="*60)
        print("RÉSUMÉ DES TESTS SYSTÈME ML")
        print("="*60)
        
        total_tests = len(self.test_results['tests'])
        passed_tests = sum(1 for test in self.test_results['tests'].values() if test.get('status') == 'PASS')
        failed_tests = sum(1 for test in self.test_results['tests'].values() if test.get('status') == 'FAIL')
        partial_tests = total_tests - passed_tests - failed_tests
        
        print(f"Total des tests: {total_tests}")
        print(f"Tests réussis: {passed_tests}")
        print(f"Tests échoués: {failed_tests}")
        print(f"Tests partiels: {partial_tests}")
        print(f"Taux de réussite: {passed_tests/total_tests*100:.1f}%")
        
        print("\nDétail par test:")
        for test_name, result in self.test_results['tests'].items():
            status = result.get('status', 'UNKNOWN')
            print(f"  {test_name}: {status}")
            if status == 'FAIL' and 'error' in result:
                print(f"    Erreur: {result['error'][:100]}...")
        
        print("="*60)
    
    def save_test_results(self, filename: str = None):
        """Sauvegarde les résultats des tests"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"test_results_{timestamp}.json"
        
        results_path = self.test_data_dir / filename
        
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(self.test_results, f, indent=2, ensure_ascii=False, default=str)
        
        logger.info(f"Résultats sauvegardés: {results_path}")
        return results_path


def run_quick_test():
    """Test rapide pour vérification de base"""
    print("=== TEST RAPIDE ===")
    
    try:
        # Test import
        from src.project_planner.ml.estimator_model import EstimatorModel
        print("✓ Import EstimatorModel OK")
        
        # Test création modèle
        model = EstimatorModel()
        print("✓ Création modèle OK")
        
        # Test données synthétiques
        from src.project_planner.ml.synthetic_generator import EnhancedSyntheticGenerator
        generator = EnhancedSyntheticGenerator()
        tasks = generator.generate_realistic_tasks(10)
        print(f"✓ Génération de {len(tasks)} tâches OK")
        
        # Test prédiction heuristique
        prediction = model.predict_task_estimates(tasks[0])
        print(f"✓ Prédiction heuristique: {prediction['duration']}j, {prediction['cost']}€")
        
        return True
        
    except Exception as e:
        print(f"✗ Erreur: {e}")
        return False


def main():
    """Point d'entrée principal pour les tests"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Tests du système ML PlannerIA')
    parser.add_argument('--quick', action='store_true', help='Test rapide seulement')
    parser.add_argument('--output', type=str, help='Fichier de sortie pour les résultats')
    
    args = parser.parse_args()
    
    if args.quick:
        success = run_quick_test()
        return 0 if success else 1
    
    # Tests complets
    try:
        tester = MLSystemTester()
        results = tester.run_all_tests()
        
        if args.output:
            tester.save_test_results(args.output)
        else:
            tester.save_test_results()
        
        # Code de retour basé sur les résultats
        failed_tests = sum(1 for test in results['tests'].values() 
                          if test.get('status') == 'FAIL')
        
        return 0 if failed_tests == 0 else 1
        
    except KeyboardInterrupt:
        logger.info("Tests interrompus par l'utilisateur")
        return 1
    except Exception as e:
        logger.error(f"Erreur fatale lors des tests: {e}")
        return 1


if __name__ == "__main__":
    # Création des répertoires de test
    Path("test_data").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)
    
    exit_code = main()
    print(f"\nTests terminés avec code: {exit_code}")
    sys.exit(exit_code)