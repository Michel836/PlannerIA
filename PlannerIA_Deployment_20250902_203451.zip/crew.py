#!/usr/bin/env python3
"""
PlannerIA - Solution corrigée sans boucles infinies
Élimination des outils problématiques et simplification des agents
"""

import os
import sys
import json
import uuid
import logging
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

# Configuration logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Imports PlannerIA - CONNEXION RÉELLE ACTIVÉE
from src.project_planner.agents.validator import PlanValidator
from src.project_planner.core.optimizer import ProjectOptimizer
from src.project_planner.ml.estimator_model import EstimatorModel

logger.info("✅ Modules PlannerIA chargés avec succès - LLM Activé!")

# Imports CrewAI
try:
    from crewai import Agent, Task, Crew, Process
    from crewai.llm import LLM
except ImportError as e:
    logger.error(f"CrewAI manquant: {e}")
    sys.exit(1)

# --- CONSTANTES ---
DEFAULT_MODEL = "ollama/llama3.2:latest"
_estimator_model = None

def initialize_ml():
    """Initialise le modèle ML global"""
    global _estimator_model
    try:
        _estimator_model = EstimatorModel()
        logger.info("EstimatorModel initialisé")
    except Exception as e:
        logger.warning(f"ML non disponible: {e}")
        _estimator_model = None

# --- SUPPRESSION COMPLETE DU RAG ---
# Le RAG causait les boucles infinies, on l'élimine complètement

# --- CLASSE PRINCIPALE SIMPLIFIÉE ---
class PlannerIA:
    def __init__(self):
        logger.info("Initialisation PlannerIA simplifiée...")
        
        # Initialisation ML uniquement
        initialize_ml()
        
        # Initialisation LLM avec gestion d'erreur
        try:
            self.llm = LLM(model=DEFAULT_MODEL)
        except Exception as e:
            logger.error(f"Erreur LLM: {e}")
            raise
        
        # Composants PlannerIA avec fallback
        try:
            self.validator = PlanValidator()
            self.optimizer = ProjectOptimizer()
        except:
            logger.warning("Composants PlannerIA non disponibles, utilisation fallback")
            self.validator = None
            self.optimizer = None
        
        # Répertoires
        for directory in ["data/runs", "logs"]:
            Path(directory).mkdir(parents=True, exist_ok=True)

    def create_agents(self) -> Dict[str, Agent]:
        """Crée des agents SIMPLIFIÉS sans outils problématiques"""
        logger.info("Création des agents simplifiés...")
        
        agents = {}
        
        # AGENT PLANNER UNIQUE - fait tout en une fois
        agents["planner"] = Agent(
            role="Expert Project Planner",
            goal="Create complete e-commerce project plan in valid JSON format",
            backstory="""You are an expert project planner specializing in e-commerce applications.
            You create comprehensive project plans with realistic estimates.
            
            CRITICAL REQUIREMENTS:
            - ALWAYS respond with ONLY valid JSON
            - NO additional text, explanations, or formatting
            - Include ALL required sections in one response
            - Use realistic durations and costs for a 3-person team
            
            EXACT JSON FORMAT REQUIRED:
            {
                "project_overview": {
                    "title": "Application E-commerce avec Paiement",
                    "description": "Description détaillée du projet",
                    "objectives": ["Objectif 1", "Objectif 2", "Objectif 3"],
                    "total_duration": 60,
                    "total_cost": 48000,
                    "team_size": 3
                },
                "wbs": {
                    "phases": [
                        {
                            "id": "phase_1",
                            "name": "Planification et Conception",
                            "duration": 15,
                            "tasks": [
                                {
                                    "id": "task_1_1",
                                    "name": "Analyse des besoins",
                                    "description": "Analyse détaillée des besoins e-commerce",
                                    "duration": 5.0,
                                    "cost": 4000.0,
                                    "priority": "high",
                                    "complexity_level": "medium",
                                    "task_type": "analysis",
                                    "resources": ["Business Analyst", "Product Owner"]
                                }
                            ]
                        }
                    ]
                },
                "risks": [
                    {
                        "id": "risk_1", 
                        "name": "Complexité technique",
                        "probability": 3,
                        "impact": 4,
                        "mitigation": "Stratégie de mitigation"
                    }
                ],
                "milestones": [
                    {
                        "id": "milestone_1",
                        "name": "Fin de conception", 
                        "date": "2025-09-15",
                        "deliverables": ["Architecture", "Spécifications"]
                    }
                ]
            }""",
            verbose=True,
            tools=[],  # AUCUN OUTIL - évite les boucles
            llm=self.llm,
            max_iter=1,  # UNE SEULE ITÉRATION
            allow_delegation=False  # Pas de délégation
        )
        
        return agents

    def create_tasks(self, brief: str, agents: Dict[str, Agent]) -> List[Task]:
        """Crée une SEULE tâche simplifiée"""
        
        tasks = [
            Task(
                description=f"""Créez un plan de projet complet pour: {brief}

CONTEXTE:
- Application e-commerce avec paiement en ligne
- Équipe de 3 développeurs
- Budget de 50 000€
- Délai de 2 mois (60 jours)

EXIGENCES TECHNIQUES:
- Frontend moderne (React/Vue.js)
- Backend API (Node.js/Python)
- Base de données (PostgreSQL/MongoDB)  
- Système de paiement (Stripe/PayPal)
- Sécurité SSL et authentification
- Tests automatisés
- Déploiement cloud

PHASES REQUISES:
1. Planification et Conception (15 jours)
2. Développement Frontend (20 jours)
3. Développement Backend (15 jours)  
4. Intégration et Tests (10 jours)

CRITIQUE: Retournez UNIQUEMENT du JSON valide. Pas de texte supplémentaire.
Chaque phase doit contenir 3-5 tâches détaillées avec durées et coûts réalistes.""",
                
                expected_output="JSON complet avec toutes les sections requises",
                agent=agents["planner"]
            )
        ]
        
        return tasks

    def generate_plan(self, brief: str) -> Dict[str, Any]:
        """Génère le plan avec maximum de simplicité"""
        run_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        logger.info(f"Génération plan - Run: {run_id}")
        logger.info(f"Brief: {brief}")

        try:
            # Création et exécution SIMPLIFIÉE
            agents = self.create_agents()
            tasks = self.create_tasks(brief, agents)
            
            crew = Crew(
                agents=list(agents.values()),
                tasks=tasks,
                process=Process.sequential,
                verbose=True,
                memory=False,
                max_execution_time=300  # Timeout de 5 minutes
            )

            logger.info("Lancement workflow simplifié...")
            result = crew.kickoff()

            # Traitement du résultat avec timeout
            plan_data = self._process_result_safe(result, brief, run_id, timestamp)
            
            # Validation optionnelle
            if self.validator:
                try:
                    plan_data = self.validator.validate_plan(plan_data)
                except:
                    logger.warning("Validation échouée, utilisation plan brut")
            
            if self.optimizer:
                try:
                    plan_data = self.optimizer.optimize_plan(plan_data)
                except:
                    logger.warning("Optimisation échouée, utilisation plan validé")
            
            # Sauvegarde
            self._save_run(run_id, plan_data)
            
            logger.info(f"Plan généré avec succès: {run_id}")
            return plan_data

        except Exception as e:
            logger.error(f"Erreur génération: {e}")
            return self._create_fallback_plan(brief, run_id, timestamp)

    def _process_result_safe(self, result, brief: str, run_id: str, timestamp: str) -> Dict[str, Any]:
        """Traite le résultat avec protection contre les erreurs"""
        
        try:
            result_str = str(result).strip()
            logger.info(f"Résultat reçu: {len(result_str)} caractères")
            
            # Tentative d'extraction JSON directe
            if result_str.startswith('{') and result_str.endswith('}'):
                try:
                    plan_data = json.loads(result_str)
                    logger.info("JSON direct parsé avec succès")
                    return self._enrich_plan_metadata(plan_data, brief, run_id, timestamp)
                except json.JSONDecodeError as e:
                    logger.warning(f"JSON direct invalide: {e}")
            
            # Extraction depuis blocs de code
            import re
            json_patterns = [
                r'```json\s*(\{.*?\})\s*```',
                r'```\s*(\{.*?\})\s*```', 
                r'(\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\})'
            ]
            
            for pattern in json_patterns:
                matches = re.findall(pattern, result_str, re.DOTALL)
                for match in reversed(matches):  # Tenter le dernier en premier
                    try:
                        plan_data = json.loads(match.strip())
                        if self._is_valid_plan_structure(plan_data):
                            logger.info(f"JSON extrait avec pattern: {pattern}")
                            return self._enrich_plan_metadata(plan_data, brief, run_id, timestamp)
                    except:
                        continue
            
            # Si échec total, utiliser le fallback
            logger.warning("Aucun JSON valide trouvé, utilisation fallback")
            return self._create_fallback_plan(brief, run_id, timestamp)
                
        except Exception as e:
            logger.error(f"Erreur traitement résultat: {e}")
            return self._create_fallback_plan(brief, run_id, timestamp)

    def _is_valid_plan_structure(self, data: Dict[str, Any]) -> bool:
        """Vérifie si la structure ressemble à un plan valide"""
        required_keys = ['project_overview', 'wbs']
        return isinstance(data, dict) and any(key in data for key in required_keys)

    def _enrich_plan_metadata(self, plan_data: Dict[str, Any], brief: str, run_id: str, timestamp: str) -> Dict[str, Any]:
        """Enrichit le plan avec les métadonnées"""
        
        # Ajout métadonnées
        plan_data.update({
            "run_id": run_id,
            "timestamp": timestamp,
            "brief": brief,
            "ml_enhanced": _estimator_model is not None,
            "generation_method": "crewai_simplified"
        })
        
        # Validation structure minimale
        if "project_overview" not in plan_data:
            plan_data["project_overview"] = self._create_default_overview(brief)
        
        if "wbs" not in plan_data:
            plan_data["wbs"] = self._create_default_wbs(brief)
        
        # Calcul des totaux
        self._calculate_totals(plan_data)
        
        return plan_data

    def _calculate_totals(self, plan_data: Dict[str, Any]):
        """Calcule les totaux depuis les tâches"""
        if "wbs" not in plan_data or "phases" not in plan_data["wbs"]:
            return
        
        total_duration = 0
        total_cost = 0
        
        for phase in plan_data["wbs"]["phases"]:
            if "tasks" in phase:
                for task in phase["tasks"]:
                    duration = task.get("duration", 0)
                    cost = task.get("cost", 0)
                    
                    if isinstance(duration, (int, float)):
                        total_duration += duration
                    if isinstance(cost, (int, float)):
                        total_cost += cost
        
        if total_duration > 0:
            plan_data["project_overview"]["total_duration"] = total_duration
        if total_cost > 0:
            plan_data["project_overview"]["total_cost"] = total_cost
            
        logger.info(f"Totaux calculés: {total_duration} jours, {total_cost}€")

    def _create_default_overview(self, brief: str) -> Dict[str, Any]:
        """Crée un aperçu par défaut basé sur le brief"""
        import hashlib
        import random
        
        # Créer une seed basée sur le brief pour avoir des données cohérentes mais différentes
        brief_hash = int(hashlib.md5(brief.encode()).hexdigest()[:8], 16)
        random.seed(brief_hash)
        
        # Détecter le type de projet et ajuster le titre
        brief_lower = brief.lower()
        if any(word in brief_lower for word in ["medical", "médical", "santé", "health", "clinique", "medi"]):
            title = "Système IA de Support Médical"
            base_cost = random.randint(35000, 65000)
            base_duration = random.randint(45, 75)
        elif any(word in brief_lower for word in ["fintech", "banking", "financial", "finance", "crédit", "paiement"]):
            title = "Application FinTech Innovante"
            base_cost = random.randint(45000, 85000) 
            base_duration = random.randint(60, 120)
        elif any(word in brief_lower for word in ["saas", "pme", "gestion", "management", "crm"]):
            title = "Plateforme SaaS de Gestion"
            base_cost = random.randint(30000, 70000)
            base_duration = random.randint(50, 90)
        elif any(word in brief_lower for word in ["e-commerce", "ecommerce", "boutique", "marketplace"]):
            title = "Application E-commerce Avancée"
            base_cost = random.randint(25000, 55000)
            base_duration = random.randint(40, 80)
        else:
            # Projet générique avec variation
            title = f"Projet Innovant {brief[:30]}..."
            base_cost = random.randint(35000, 65000)
            base_duration = random.randint(45, 85)
        
        return {
            "title": title,
            "description": brief,
            "objectives": [
                "Développer une solution innovante et performante",
                "Assurer une intégration technique robuste", 
                "Optimiser l'expérience utilisateur",
                "Garantir la sécurité et la conformité"
            ],
            "total_duration": base_duration,
            "total_cost": base_cost,
            "team_size": random.randint(3, 7)
        }

    def _create_default_wbs(self, brief: str) -> Dict[str, Any]:
        """Crée un WBS par défaut basé sur le brief"""
        import hashlib
        import random
        
        # Utiliser la même seed que pour l'overview
        brief_hash = int(hashlib.md5(brief.encode()).hexdigest()[:8], 16)
        random.seed(brief_hash)
        
        # Facteur de coût basé sur le type de projet
        brief_lower = brief.lower()
        if any(word in brief_lower for word in ["medical", "médical", "santé", "health", "clinique"]):
            cost_multiplier = random.uniform(1.2, 1.8)  # Projets médicaux plus chers
        elif any(word in brief_lower for word in ["fintech", "banking", "financial", "finance"]):
            cost_multiplier = random.uniform(1.3, 2.0)  # FinTech complexe
        elif any(word in brief_lower for word in ["saas", "pme", "gestion"]):
            cost_multiplier = random.uniform(0.8, 1.4)  # SaaS variable
        else:
            cost_multiplier = random.uniform(1.0, 1.5)  # Défaut
            
        base_task_cost = 3000 * cost_multiplier
        
        # Générer des tâches simplifiées mais variables
        tasks_phase1 = []
        tasks_phase2 = []
        
        # Phase 1 - tâches de conception
        for i, (task_name, desc_suffix) in enumerate([
            ("Analyse des besoins", "fonctionnels et techniques"),
            ("Architecture technique", "et conception système"),
            ("Design UI/UX", "et prototypes")
        ]):
            tasks_phase1.append({
                "id": f"task_1_{i+1}",
                "name": task_name,
                "description": f"{task_name} - {desc_suffix}",
                "duration": random.uniform(3, 8),
                "cost": base_task_cost * random.uniform(0.8, 1.4),
                "priority": "high" if i < 2 else "medium"
            })
        
        # Phase 2 - tâches de développement  
        for i, (task_name, desc_suffix) in enumerate([
            ("Développement Core", "fonctionnalités principales"),
            ("Intégrations", "APIs et services externes"),
            ("Tests et validation", "qualité et performance")
        ]):
            tasks_phase2.append({
                "id": f"task_2_{i+1}",
                "name": task_name,
                "description": f"{task_name} - {desc_suffix}",
                "duration": random.uniform(8, 15),
                "cost": base_task_cost * random.uniform(1.2, 2.0),
                "priority": "high"
            })

        return {
            "phases": [
                {
                    "id": "phase_1",
                    "name": "Planification et Conception", 
                    "duration": sum(t["duration"] for t in tasks_phase1),
                    "tasks": tasks_phase1
                },
                {
                    "id": "phase_2", 
                    "name": "Développement et Tests",
                    "duration": sum(t["duration"] for t in tasks_phase2),
                    "tasks": tasks_phase2
                }
            ]
        }

    def _create_fallback_plan(self, brief: str, run_id: str, timestamp: str) -> Dict[str, Any]:
        """Plan de secours complet"""
        logger.info("Création plan de secours")
        
        plan = {
            "run_id": run_id,
            "timestamp": timestamp,
            "brief": brief,
            "status": "fallback_generated",
            "project_overview": self._create_default_overview(brief),
            "wbs": self._create_default_wbs(brief),
            "risks": [
                {
                    "id": "risk_1",
                    "name": "Complexité technique sous-estimée",
                    "probability": "medium",
                    "impact": 4,
                    "mitigation": "Prévoir buffer de 20% sur temps et budget"
                },
                {
                    "id": "risk_2", 
                    "name": "Intégration complexe",
                    "probability": 4,
                    "impact": "medium",
                    "mitigation": "Tests précoces et validation"
                }
            ],
            "milestones": [
                {
                    "id": "milestone_1",
                    "name": "Fin de conception",
                    "date": "2025-09-15",
                    "deliverables": ["Architecture validée", "Maquettes approuvées"]
                },
                {
                    "id": "milestone_2",
                    "name": "Version finale",
                    "date": "2025-10-15", 
                    "deliverables": ["Application fonctionnelle", "Tests réussis"]
                }
            ]
        }
        
        # Calcul des totaux depuis le WBS
        self._calculate_totals(plan)
        
        return plan

    def _save_run(self, run_id: str, plan: Dict[str, Any]):
        """Sauvegarde robuste"""
        try:
            run_dir = Path(f"data/runs/{run_id}")
            run_dir.mkdir(parents=True, exist_ok=True)
            
            with open(run_dir / "plan.json", "w", encoding="utf-8") as f:
                json.dump(plan, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"Plan sauvegardé: {run_dir}")
            
        except Exception as e:
            logger.error(f"Erreur sauvegarde: {e}")

def main():
    parser = argparse.ArgumentParser(description="PlannerIA - Version corrigée")
    parser.add_argument("brief", help="Brief de projet")
    parser.add_argument("--timeout", type=int, default=300, help="Timeout en secondes")
    
    args = parser.parse_args()
    
    try:
        # Initialize PlannerIA
        planner = PlannerIA()
        logger.info("PlannerIA initialisé avec succès")
        
        # Generate plan
        logger.info(f"Génération du plan pour: {args.brief[:50]}...")
        result = planner.generate_plan(args.brief)
        
        if result and not result.get("error"):
            logger.info("✅ Plan généré avec succès!")
            # Pretty print the result
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            logger.error(f"❌ Erreur lors de la génération: {result.get('error', 'Erreur inconnue')}")
            sys.exit(1)
        
    except KeyboardInterrupt:
        logger.info("Arrêt demandé par l'utilisateur")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Erreur fatale: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()